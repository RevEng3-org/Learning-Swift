import Cocoa

import PlaygroundSupport

struct Sizes{
    static var s_uint32 = 32
    static var s_int = 32
    static var s_mach64 = 32
    static var s_mach = 28
}

enum BytestreamErrors:Error{
    case invalidOffset
    case invalidSizes
    case cantReadMemory
}

enum MemoryMapErrors:Error{
    case emptyMemory
    case invalidSizes
}

class Bytestream:NSObject{
    var data:Data
    
    init(withData d:Data){
        self.data = d
        super.init()
    }
    
    func size () -> Int{
        return self.data.endIndex
    }
    
    func readall() throws -> [UInt8]{
        var result = [UInt8]()
        var iter = self.data.makeIterator()
        let len = self.size()
        for _ in 0..<len{
            guard
                let byte = iter.next()
                else {
                    throw BytestreamErrors.cantReadMemory
            }
            result.append(byte)
        }
        return result
    }
    
    func readbytes(howMany n:Int, offset o: Int) throws -> [UInt8]{
        var result = [UInt8]()
        var iter = self.data.makeIterator()
        
        if (o+n)>self.size(){
            throw BytestreamErrors.invalidSizes
        }
        
        for _ in 0..<o{
            guard iter.next() != nil
                else {
                    throw BytestreamErrors.invalidOffset
            }
        }
        
        for _ in 0..<n{
            guard
                let byte = iter.next()
                else {
                    throw BytestreamErrors.cantReadMemory
            }
            result.append(byte)
        }
        return result
    }

}

class MemoryMap:NSObject{
    var memory:[UInt8]
    var mustSwap:Bool
    
    init(bytestream b: [UInt8], mustSwap m:Bool){
        memory = [UInt8]()
        mustSwap = m
        super.init()
        if (b.count > 0){ memory = b }
    }
    
    func returnBytes(howManyBytes h:Int, offset o:Int) throws -> [UInt8]{
        if (self.memory.count == 0){
            throw MemoryMapErrors.emptyMemory
        }
        if (h+o)>self.memory.count{
            throw MemoryMapErrors.invalidSizes
        }
        var result = [UInt8]()
        for i in h..<h+o{
            result.append(memory[i])
        }
        return result
    }
    
    func returnWords(howManyWords h:Int, offset o:Int) throws -> [UInt16]{
        if (self.memory.count == 0){
            throw MemoryMapErrors.emptyMemory
        }
        if ((2*h)+o)>self.memory.count{
            throw MemoryMapErrors.invalidSizes
        }
        var result = [UInt16]()
        var i = o
        var ic = 0
        while (ic<h){
            let num1 = memory[i]
            i += 1
            let num2 = memory[i]
            i += 1
            var num: UInt16
            if (mustSwap) {
                num = (UInt16(num1) << 8) | UInt16(num2)
            } else {
                num = (UInt16(num2) << 8) | UInt16(num1)
            }
            ic += 1
            result.append(num)
        }
        return result
    }
    
    func returnDwords(howManyWords h:Int, offset o:Int) throws -> [UInt32]{
        if (self.memory.count == 0){
            throw MemoryMapErrors.emptyMemory
        }
        if ((4*h)+o)>self.memory.count{
            throw MemoryMapErrors.invalidSizes
        }
        
        var result = [UInt32]()
        var i = o
        var ic = 0
        while (ic<h){
            let num1 = memory[i]
            i += 1
            let num2 = memory[i]
            i += 1
            let num3 = memory[i]
            i += 1
            let num4 = memory[i]
            i += 1
            
           var num: UInt32
           if (mustSwap) {
               num = (((UInt32(num1) << 8) | UInt32(num2)) << 8 | UInt32(num3)) << 8 | UInt32(num4)
           } else {
               num = (((UInt32(num4) << 8) | UInt32(num3)) << 8 | UInt32(num2)) << 8 | UInt32(num1)
           }
           ic += 1
           result.append(num)
       }
       return result
    }
    
}

var uri = NSURL(fileURLWithPath: "/Users/whatever/Desktop/dumpah")

let home = FileManager.default.homeDirectoryForCurrentUser
let path = "Desktop/dumpah"

let myUrl = home.appendingPathComponent(path)

let fileManager = FileManager.default
fileManager.fileExists(atPath: myUrl.path)

let fm = FileHandle(forReadingAtPath: myUrl.path)

if (fm == nil) {
    print ("Cannot open file")
} else {
    print ("File opened")
    let data = fm?.readDataToEndOfFile()
    let bStream = Bytestream(withData: data!)
    var bytestream = [UInt8]()
    do{
        try bytestream = bStream.readall()
        
    } catch {
        print ("couldn't read memory")
    }
}
